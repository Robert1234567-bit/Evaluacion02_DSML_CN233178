package com.example.colegio

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.colegio.databinding.ItemNoteBinding
import com.example.colegio.models.Note

class NoteAdapter(private val notes: List<Note>) :
    RecyclerView.Adapter<NoteAdapter.NoteViewHolder>() {

    inner class NoteViewHolder(val binding: ItemNoteBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        val binding = ItemNoteBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NoteViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        val note = notes[position]
        holder.binding.tvStudent.text = note.studentId
        holder.binding.tvGrade.text = note.grade
        holder.binding.tvSubject.text = note.subject
        holder.binding.tvFinalNote.text = note.finalNote.toString()
    }

    override fun getItemCount(): Int = notes.size
}
