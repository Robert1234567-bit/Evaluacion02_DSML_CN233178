package com.example.colegio.models

data class Student(
    var id: String = "",
    var name: String = "",
    var age: Int = 0,
    var address: String = "",
    var phone: String = ""
)
