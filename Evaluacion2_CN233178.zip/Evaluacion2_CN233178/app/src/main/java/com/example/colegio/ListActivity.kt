package com.example.colegio

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.colegio.databinding.ActivityListBinding
import com.example.colegio.models.Student
import com.google.firebase.firestore.FirebaseFirestore

class ListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityListBinding
    private val db = FirebaseFirestore.getInstance()
    private val students = mutableListOf<Student>()
    private lateinit var adapter: StudentAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListBinding.inflate(layoutInflater)
        setContentView(binding.root)



        adapter = StudentAdapter(students)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        loadStudents()
    }
private fun loadStudents() {
        db.collection("students").get().addOnSuccessListener { result ->
            students.clear()
            for(doc in result){
                val student = doc.toObject(Student::class.java)
                student.id = doc.id
                students.add(student)
            }
            adapter.notifyDataSetChanged()
        }.addOnFailureListener { Toast.makeText(this, it.message, Toast.LENGTH_SHORT).show() }
    }
}
