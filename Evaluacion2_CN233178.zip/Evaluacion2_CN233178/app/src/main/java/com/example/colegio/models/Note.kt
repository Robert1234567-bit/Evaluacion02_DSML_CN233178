package com.example.colegio.models

data class Note(
    var id: String = "",
    var studentId: String = "",
    var grade: String = "",
    var subject: String = "",
    var finalNote: Double = 0.0
)
