package com.example.colegio

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.colegio.databinding.ActivityAddStudentBinding
import com.example.colegio.models.Student
import com.google.firebase.firestore.FirebaseFirestore

class AddStudentActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddStudentBinding
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddStudentBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.saveStudent.setOnClickListener {
            val name = binding.etName.text.toString()
            val ageText = binding.etAge.text.toString()
            val address = binding.etAddress.text.toString()
            val phone = binding.etPhone.text.toString()

            if(name.isEmpty() || ageText.isEmpty() || address.isEmpty() || phone.isEmpty()) {
                Toast.makeText(this, getString(R.string.err_empty), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val age = ageText.toIntOrNull()
            if(age == null) {
                Toast.makeText(this, "Edad inválida", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val student = Student(name = name, age = age, address = address, phone = phone)
            db.collection("students").add(student).addOnSuccessListener {
                Toast.makeText(this, getString(R.string.student_saved), Toast.LENGTH_SHORT).show()
                finish()
            }.addOnFailureListener {
                Toast.makeText(this, it.message, Toast.LENGTH_SHORT).show()
            }
        }
    }
}
