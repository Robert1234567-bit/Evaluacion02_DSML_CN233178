package com.example.colegio

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.colegio.databinding.ActivityAddNoteBinding
import com.example.colegio.models.Note
import com.google.firebase.firestore.FirebaseFirestore

class AddNoteActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddNoteBinding
    private val db = FirebaseFirestore.getInstance()
    private val grades = listOf("1", "2", "3", "4", "5", "6")
    private val subjects = listOf("Matemáticas", "Ciencias", "Historia", "Lengua")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddNoteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        
binding.spinnerGrade.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, grades)
        binding.spinnerSubject.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, subjects)

        
        db.collection("students").get().addOnSuccessListener { result ->
            val students = result.map { it.id to it.getString("name")!! }
            val names = students.map { it.second }
            binding.spinnerStudent.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, names)
         binding.saveNote.setOnClickListener {
                val studentIndex = binding.spinnerStudent.selectedItemPosition
                val studentId = students[studentIndex].first
                val grade = binding.spinnerGrade.selectedItem.toString()
                val subject = binding.spinnerSubject.selectedItem.toString()
                val noteText = binding.etNote.text.toString()
                val note = noteText.toDoubleOrNull()

    if(note == null || note < 0 || note > 10){
             Toast.makeText(this, getString(R.string.err_invalid_note), Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val noteObj = Note(studentId = studentId, grade = grade, subject = subject, finalNote = note)
                db.collection("notes").add(noteObj).addOnSuccessListener {
                    Toast.makeText(this, getString(R.string.note_saved), Toast.LENGTH_SHORT).show()
                    finish()
                }.addOnFailureListener { Toast.makeText(this, it.message, Toast.LENGTH_SHORT).show() }
            }

        }


    }
    
}
